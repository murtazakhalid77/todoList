package com.example.Todolist.service;

import com.example.Todolist.domain.Task;
import com.example.Todolist.repository.TaskRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TaskService {

    private final TaskRepository taskRepository;

    public TaskService(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }

    public Task save(Task task) {
        try {
            Task t = taskRepository.getByDescriptionAndComment(task.getDescription(),task.getComment());
            if(t==null)
                return taskRepository.save(task);
        }catch (Exception ex){
            throw new RuntimeException("Error Occurred");
        }
        throw new RuntimeException("Task Already Present");
    }

    public List<Task> getAll() {
        return taskRepository.findAll();
    }

    public Task getTaskByDescriptionAndComment(String description, String comment){
        return taskRepository.getByDescriptionAndComment(description,comment);
    }
}
