package com.example.Todolist.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import javax.persistence.*;
import lombok.*;

import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
@Data
public class ToDoList {
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ToDoList)) return false;
        ToDoList toDoList = (ToDoList) o;
        return getName().equals(toDoList.getName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getName());
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String name;

//    @JsonIgnore
    @ManyToMany(mappedBy = "list",cascade = CascadeType.ALL)
    private Set<Task> tasks = new HashSet<>();

}
